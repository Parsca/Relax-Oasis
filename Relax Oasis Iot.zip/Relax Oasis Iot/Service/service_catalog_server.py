import json
import cherrypy

class ServiceCatalogManager(object):
    def __init__(self):
        self.settings = "catalog_service.json"
        self.conf = json.load(open(self.settings))
        
    exposed = True
    
    def GET(self, *uri, **parameters):
        print('GET')
        if len(uri) == 1:
            self.conf = json.load(open(self.settings))
            
            if uri[0] == 'res_cat':
                resources = json.dumps(self.conf["resource_catalogs"])
                print('RES: ', resources)
                return resources        # restituisce info sui resource catalogs
            
            elif uri[0] == 'microservice_cat':
                microservices = json.dumps(self.conf["microservices"])
                print('MICROS: ', microservices)
                return microservices    # restituisce info sui microservices
            
            elif uri[0] == 'microservice_IP':
                microservice_IP = self.get_microservice_IP(parameters["name_microservices"])
                return microservice_IP    # restituisce info su IP dei microservices
            
            elif uri[0] == 'microservice_info':
                microservice_IP = self.get_microservice_info(parameters["name_microservices"])
                return microservice_IP    # restituisce info su IP dei microservices
            
            elif uri[0] == 'broker':
                output_site = self.conf['broker']
                output_port = self.conf['broker_port']
                output = {                
                    'broker_port': output_port,
                    'broker': output_site, 
                }    
                print(output)
                return output

            elif uri[0] == 'base_topic':
                return json.dumps(self.conf["base_topic"])
            
        else:
            error_string = "incorrect URI or PARAMETERS URI"
            raise cherrypy.HTTPError(400, error_string)
    
    def POST(self, *uri, **parameters):   # scrittura nel json "service_catalog.json" dei resource catalogs ricevuti nel body
        self.conf = json.load(open(self.settings))
        if len(uri) == 1:             
            body = cherrypy.request.body.read()  # lettura dei resource catalog dal body inviato da resource_catalog_server.py (mediante POST)
            operation = uri[0]      
            if operation == "resource":
                self.insertResCat(body)  # scrittura dei resource catalog
            elif operation == "microservice":
                self.insertMicroservices(body)  # scrittura dei microservices
        else:
            error_string = "incorrect URI or PARAMETERS"
            raise cherrypy.HTTPError(400, error_string)    
    
    def insertResCat(self, json_body):
        # Verifica se json_body è di tipo bytes e lo decodifica
        if isinstance(json_body, bytes):
            json_body = json_body.decode('utf-8')  # Decodifica in una stringa UTF-8

        # Converte la stringa JSON in un dizionario Python
        json_body = json.loads(json_body)

        # Aggiunge il nuovo resource catalog solo se non è già presente
        if json_body not in self.conf['resource_catalogs']:
            print('NEW RESOURCE: ', json_body)
            self.conf['resource_catalogs'].append(json_body)

            # Scrive i dati aggiornati nel file
            with open(self.settings, "w") as f:
                json.dump(self.conf, f, indent=4)  # indent per rendere il JSON più leggibile
    
    def insertMicroservices(self, json_body):
        # Verifica se json_body è di tipo bytes e lo decodifica
        if isinstance(json_body, bytes):
            json_body = json_body.decode('utf-8')  # Decodifica in una stringa UTF-8

        # Converte la stringa JSON in un dizionario Python
        json_body = json.loads(json_body)

        # Aggiunge il nuovo microservizio solo se non è già presente
        if json_body not in self.conf['microservices']:
            print('NEW MICROSERVICE: ', json_body)
            self.conf['microservices'].append(json_body)

            # Scrive i dati aggiornati nel file
            with open(self.settings, "w") as f:
                json.dump(self.conf, f, indent=4)  # indent per rendere
    
    def get_microservice_IP(self, name_microservice):
        for microservice in self.conf.get('microservices', []):
            if microservice.get('name_microservice') == name_microservice:
                result = {
                    "ip_address": microservice.get('ip_address'),
                    "ip_port": microservice.get('ip_port')
                }
                return json.dumps(result)  # Converte il risultato in formato JSON
        return json.dumps({"ip_address": None, "ip_port": None})

    def get_microservice_info(self, name_microservice):
        for microservice in self.conf.get('microservices', []):
            if microservice.get('name_microservice') == name_microservice:
                # Estrai tutti i parametri richiesti
                result = {
                    "key": microservice.get('key'),
                    "url": microservice.get('url'),
                    "url_channels": microservice.get('url_channels'),
                    "url_feed": microservice.get('url_feed'),
                    "ip_address": microservice.get('ip_address'),
                    "ip_port": microservice.get('ip_port')
                }
                return json.dumps(result)  # Converte il risultato in formato JSON
        # Restituisci un messaggio di errore se il microservizio non è trovato
        return json.dumps({"error": "Microservice not found"})



    def getPort(self):
        return self.conf['ip_port']

    def getBrokerPort(self):
        return self.conf['broker_port']


if __name__ == "__main__":
    setting_file = 'settings_service_catalog.json'
    service_info = json.load(open(setting_file))  # Cerca il file nelle sottocartelle
    
    conf = {
        '/': {
            'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
            'tools.sessions.on': True, 
        }
    }
    cherrypy.tree.mount(ServiceCatalogManager(), '/', conf)
    cherrypy.config.update(conf)
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.config.update({"server.socket_port": ServiceCatalogManager().getPort()})
    cherrypy.engine.start()
    cherrypy.engine.block()