import telepot
from telepot.loop import MessageLoop
from telepot.namedtuple import InlineKeyboardMarkup, InlineKeyboardButton
import json
import requests
import time
import os
from utils import (
    load_json_file,
    get_resource_catalog,
    get_owners
)
service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

class EchoBot1:
    def __init__(self, token, service_catalog_info, res_catalog_info, ip_address, ip_port, api_key, thingspeak_url):
        self.tokenBot = token
        self.service_catalog_info = service_catalog_info
        self.res_catalog_info = res_catalog_info
        self.ip_address = ip_address
        self.ip_port = ip_port
        self.bot = telepot.Bot(self.tokenBot)
        MessageLoop(self.bot, {'chat': self.on_chat_message,
                               'callback_query': self.on_callback_query}).run_as_thread()
        self.read_resource_catalog()
        self.reset_temp_variables()

        self.api_key = api_key
        self.thingspeak_url = thingspeak_url

    def read_resource_catalog(self):
        self.rc_ip = self.res_catalog_info["ip_address"]
        self.rc_ip_port = self.res_catalog_info["ip_port"]
        print(f"Resource catalog: {self.res_catalog_info} \n")
        self.list_owners = get_owners(self.res_catalog_info)

    def reset_temp_variables(self):
        self.rooms = []
        self.chosen_owner = False
        self.requested_owner = ''
        self.chosen_room = False
        self.requested_room = ''
        self.r = {}
        self.new_owner_flag = False
        self.delete_owner_flag = False
        self.name_new_owner = ''
        self.nr_last_room = len(self.list_owners)
        self.new_channel_name = ''
        self.awaiting_password = False
        self.modified_data = False
        self.awaiting_user_id = False
        self.awaiting_first_name = False
        self.awaiting_last_name = False
        self.awaiting_email = False
        self.awaiting_phone = False
        self.awaiting_owner_user_selection = False
        self.awaiting_modify_or_new_id = False
        self.origin_command = ''
        self.delete_owner = False
        self.delete_user_flag = False

    def on_chat_message(self, msg):
        content_type, chat_type, chat_ID = telepot.glance(msg)
        message = msg['text']

        if message == "/start":
            self.bot.sendMessage(chat_ID, text='Command /operation, /new_owner, /delete_owner, or /new_user, /delete_user')
        
        elif message == "/operation":
            self.origin_command = 'operation'
            self.show_owners(chat_ID)

        elif message == "/new_owner":
            self.bot.sendMessage(chat_ID, text='Please enter the password:')
            self.awaiting_password = 'new_owner'
            
        elif message == "/delete_owner":
            self.origin_command = 'delete_owner'
            self.bot.sendMessage(chat_ID, text='Please enter the password:')
            self.awaiting_password = 'delete_owner'
        
        elif message == "/new_user":
            self.origin_command = 'new_user'
            self.bot.sendMessage(chat_ID, text='Please enter the password:')
            self.awaiting_password = 'new_user'
            
        elif message == "/delete_user":
            self.origin_command = 'delete_user'
            self.bot.sendMessage(chat_ID, text='Please enter the password:')
            self.awaiting_password = 'delete_user'
        
        elif self.awaiting_password:
            if message == "manager_room":
                if self.awaiting_password == 'new_owner':
                    self.awaiting_password = False
                    self.prompt_new_owner(chat_ID)
                if self.awaiting_password == 'delete_owner':
                    self.awaiting_password = False
                    self.prompt_delete_owner(chat_ID)
                elif self.awaiting_password == 'new_user':
                    self.awaiting_password = False
                    self.show_owners(chat_ID)
                elif self.awaiting_password == 'delete_user':
                    self.awaiting_password = False
                    self.prompt_delete_user(chat_ID)
            else:
                self.awaiting_password = False
                self.bot.sendMessage(chat_ID, text='Incorrect password. Command /operation, /new_owner, /delete_owner, or /new_user, /delete_user')

        elif self.awaiting_user_id:
            self.new_user_id = message
            get_string = f'http://{self.rc_ip}:{self.rc_ip_port}/registeredUser?owner={self.requested_owner}&user_ID={self.new_user_id}'
            response = requests.get(get_string)

            if response.status_code == 200:
                response_data = json.loads(response.text)
                
                # Controlla se l'utente è già registrato in quella stanza
                if response_data.get("error") == "User already registered in the specified room":
                    print("L'utente è già registrato in questa stanza")
                    self.awaiting_modify_or_new_id = True
                    self.bot.sendMessage(chat_ID, text='User already registered in the specified room')
                    self.bot.sendMessage(chat_ID, text='Would you like to modify the user data or try a new ID? Reply with /modify_user or /new_user')
                else:
                    if response_data.get("message") == "User registered but not in the specified room":
                        print("L'utente è registrato ma non in questa stanza.")
                        self.modify_user_authorization(chat_ID)
                    elif response_data.get("message") == "User NOT registered":
                        print("L'utente non è registrato.")
                        # Aggiungi qui il codice per gestire questa situazione
                        self.bot.sendMessage(chat_ID, text='Please enter the new user first name:')
                        self.awaiting_first_name = True
                self.awaiting_user_id = False
            else:
                print(f"Errore nella richiesta: {response.status_code}")

        elif self.awaiting_first_name:
            self.new_user_first_name = message
            self.bot.sendMessage(chat_ID, text='Please enter the new user last name:')
            self.awaiting_last_name = True
            self.awaiting_first_name = False

        elif self.awaiting_last_name:
            self.new_user_last_name = message
            self.bot.sendMessage(chat_ID, text='Please enter the new user email:')
            self.awaiting_email = True
            self.awaiting_last_name = False

        elif self.awaiting_email:
            self.new_user_mail = message
            self.bot.sendMessage(chat_ID, text='Please enter the new user phone number:')
            self.awaiting_phone = True
            self.awaiting_email = False

        elif self.awaiting_phone and not self.modified_data:
            self.new_user_phone_number = message
            self.awaiting_phone = False
            self.new_user_data = {
                "user_ID": self.new_user_id,  # Use "user_ID" as per server expectation
                "first_name": self.new_user_first_name,  # Adjust field names as necessary
                "last_name": self.new_user_last_name,
                "email": self.new_user_mail,
                "phone_number": int(self.new_user_phone_number),  # Ensure this is an integer
                "room_authorization":[self.requested_owner]  # Assuming the room to which the user is authorized is the requested owner
            }
            self.add_new_user_to_room(chat_ID)
            self.new_user = False
        
        elif self.awaiting_phone and self.modified_data:
            self.new_user_phone_number = message
            self.awaiting_phone = False

            # At this point, we have all the information needed to create a new user.
            self.modified_user = {
                "user_ID": self.new_user_id,  # Use "user_ID" as per server expectation
                "first_name": self.new_user_first_name,  # Adjust field names as necessary
                "last_name": self.new_user_last_name,
                "email": self.new_user_mail,
                "phone_number": int(self.new_user_phone_number),  # Ensure this is an integer
                "room_authorization":[self.requested_owner]  # Assuming the room to which the user is authorized is the requested owner
            }
            self.modify_user_data(chat_ID)
        
        elif self.awaiting_modify_or_new_id:
            if message == "/modify_user":
                self.bot.sendMessage(chat_ID, text='Please provide the updated user information: \nFirst name:')
                self.awaiting_user_id = False
                self.awaiting_first_name = True
                self.modified_data = True
                self.modify_user = False
            elif message == "/new_user":
                self.bot.sendMessage(chat_ID, text='Please enter the new user ID:')
                self.awaiting_user_id = True
                self.modified_data = False
            self.awaiting_modify_or_new_id = False

        elif self.new_owner_flag:
            self.create_new_owner(chat_ID, message)
        elif self.delete_owner_flag:
            self.delete_new_owner(chat_ID, message)
        elif self.delete_user_flag:
            self.delete_new_user(chat_ID, message)
        else:
            self.bot.sendMessage(chat_ID, text="Command not supported")

    def show_owners(self, chat_ID):
        if len(self.list_owners) == 0:
            # Send a message when no owners are registered
            self.bot.sendMessage(chat_ID, text="At the moment, there are no registered owners. You can add one by clicking on /new_owner.")
        else:
            # Generate buttons for each owner
            buttons = [
                [InlineKeyboardButton(text=owner, callback_data=owner)]
                for owner in self.list_owners
            ]
            keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
            self.bot.sendMessage(chat_ID, text='Which owner are you interested in?', reply_markup=keyboard)
            self.awaiting_owner_user_selection = True

    def prompt_new_owner(self, chat_ID):
        self.bot.sendMessage(chat_ID, text='Insert the name of the new Relax Room')
        self.new_owner_flag = True
        
    def prompt_delete_owner(self, chat_ID):
        self.bot.sendMessage(chat_ID, text='Insert the name of the Relax Room to delete')
        self.delete_owner_flag = True
    
    def prompt_delete_user(self, chat_ID):
        self.bot.sendMessage(chat_ID, text='Insert the name of the user to delete')
        self.delete_user_flag = True

    def create_new_owner(self, chat_ID, owner_name):
        self.name_new_owner = owner_name
        self.nr_last_room += 1
        self.on_create_new_room(chat_ID)
        self.new_owner_flag = False
        
    def delete_new_owner(self, chat_ID, owner_name):
        self.name_delete_owner = owner_name
        self.nr_last_room += 1
        self.on_delete_new_room(chat_ID)
        self.delete_owner_flag = False
        
    def delete_new_user(self, chat_ID, user_name):
        self.name_delete_user = user_name
        self.nr_last_room += 1
        self.on_delete_new_user(chat_ID)
        self.delete_user_flag = False

    def on_callback_query(self, msg):
        query_ID, chat_ID, query_data = telepot.glance(msg, flavor='callback_query')
        
        if self.awaiting_owner_user_selection:
            self.requested_owner = query_data
            print(f"Owner selected: {self.requested_owner}")
            if self.origin_command == 'operation':
                self.show_available_measure_buttons(chat_ID)
            elif self.origin_command == 'new_user':
                self.bot.sendMessage(chat_ID, text='Please enter the new user ID:')
                self.awaiting_user_id = True
                self.modified_data = False
            self.awaiting_owner_user_selection = False
        
        elif self.chosen_owner and not self.awaiting_owner_user_selection:
            self.requested_measure = query_data
            self.display_sensor_data(chat_ID, self.requested_measure)

    def show_available_measure_buttons(self, chat_ID):
        get_string = f'{resource_catalog_url}/allSensorTypes?owner={self.requested_owner}'
        response = requests.get(get_string)
        measures = response.json()
        available_measures = [measure for measure in measures['sensor_types'] if measure != 'fiscal_code']
        buttons = [
            [InlineKeyboardButton(text=measure.capitalize(), callback_data=measure)]
            for measure in available_measures
        ]
        keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
        if buttons:
            self.bot.sendMessage(chat_ID, text=f'Select a measure type for owner {self.requested_owner}:', reply_markup=keyboard)
            self.chosen_owner = True
            self.awaiting_owner_user_selection = False
        else:
            self.bot.sendMessage(chat_ID, text='No sensors available for the selected owner.')
            self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

    def add_new_user_to_room(self, chat_ID):
        output = self.new_user_data
        try:
            poststring = f'{resource_catalog_url}/user'
            response = requests.post(poststring, json=output)
            
            if response.status_code == 409:  # Conflict status indicates the user is already registered
                print(f"User already registered with ID: {self.new_user_id} in {self.requested_owner}.")
                self.bot.sendMessage(chat_ID, text=f"User already registered with ID '{self.new_user_id}' in {self.requested_owner}.")
                self.bot.sendMessage(chat_ID, text='Would you like to modify the user data or try a new ID? Reply with /modify_user or /new_user')

                # Impostiamo il flag per aspettare la scelta dell'utente
                self.awaiting_modify_or_new_id = True

            else:
                # Se l'utente non esiste, continuiamo con l'aggiunta
                response.raise_for_status()
                self.bot.sendMessage(chat_ID, text=f"New user {self.new_user_first_name} {self.new_user_last_name} successfully added to room {self.requested_owner}.")
                self.read_resource_catalog()  # Aggiorna il catalogo delle risorse
                self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

        except requests.exceptions.HTTPError as err:
            # Gestione degli errori HTTP
            print(f"HTTP error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"HTTP error occurred: {err}")

    def modify_user_data(self, chat_ID):
        output = self.modified_user
        try:
            putstring = f'{resource_catalog_url}/userUpdate'
            response = requests.put(putstring, json=output)
            response.raise_for_status()
            self.bot.sendMessage(chat_ID, text=f"User {self.new_user_first_name} {self.new_user_last_name} successfully modified in room {self.requested_owner}.")
            self.read_resource_catalog()
            self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

        except requests.exceptions.HTTPError as err:
            print(f"HTTP error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"HTTP error occurred: {err}")
            
    def modify_user_authorization(self, chat_ID):
        output = {"user_ID": self.new_user_id,
                "room_authorization": [self.requested_owner]}
        try:
            putstring = f'{resource_catalog_url}/userAuthorizationUpdate'
            response = requests.put(putstring, json=output)
            response.raise_for_status()
            self.bot.sendMessage(chat_ID, text=f"User {self.new_user_id} is now also authorized to enter the room {self.requested_owner}.")
            self.read_resource_catalog()
            self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

        except requests.exceptions.HTTPError as err:
            print(f"HTTP error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"HTTP error occurred: {err}")
    
    def on_create_new_room(self, chat_ID):  
        self.name_new_owner = f"relax_room_{self.name_new_owner}"          
        output = {
            "owner": self.name_new_owner
        }

        try:
            poststring = f'{resource_catalog_url}/owner'
            response = requests.post(poststring, json=output)
            
            if response.status_code == 409:  # Conflict status indicates the user is already registered
                print(f"Owner already registered with name: {self.name_new_owner}")
                self.bot.sendMessage(chat_ID, text=f"Owner already registered with name: {self.name_new_owner}")
            else:
                response.raise_for_status()
                self.bot.sendMessage(chat_ID, text=f"New owner {self.name_new_owner} successfully created.")
                # URL per creare un nuovo canale
                self.create_TS_channel(chat_ID)
                self.read_resource_catalog()
            self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

        except requests.exceptions.HTTPError as err:
            print(f"HTTP error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"HTTP error occurred: {err}")
        
        except Exception as err:
            print(f"An error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"An error occurred: {err}")
            
    def on_delete_new_room(self, chat_ID):  
        self.name_delete_owner = f"relax_room_{self.name_delete_owner}"          

        try:
            delete_string = f'{resource_catalog_url}/device?device_connector_ID={self.name_delete_owner}'
            response = requests.delete(delete_string)
            output = response.json()
            if output["status"] == "success":  # Conflict status indicates the user is already registered
                print(f"Owner {self.name_delete_owner} removed")
                self.bot.sendMessage(chat_ID, text=f"Device {self.name_delete_owner} removed")
            elif output["status"] == "error":
                print(f"Owner {self.name_delete_owner} NOT found")
                self.bot.sendMessage(chat_ID, text=f"Owner {self.name_delete_owner} NOT found")
            self.delete_TS_channel(chat_ID)
            self.read_resource_catalog()
            self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

        except requests.exceptions.HTTPError as err:
            print(f"HTTP error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"HTTP error occurred: {err}")
        
        except Exception as err:
            print(f"An error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"An error occurred: {err}")
            
    def on_delete_new_user(self, chat_ID):          
        try:
            delete_string = f'{resource_catalog_url}/user?user_id={self.name_delete_user}'
            response = requests.delete(delete_string)
            output = response.json()
            if output["status"] == "success":  # Conflict status indicates the user is already registered
                print(f"User {self.name_delete_user} removed")
                self.bot.sendMessage(chat_ID, text=f"User {self.name_delete_user} removed")
            elif output["status"] == "error":
                print(f"User {self.name_delete_user} NOT found")
                self.bot.sendMessage(chat_ID, text=f"User {self.name_delete_user} NOT found")
            self.read_resource_catalog()
            self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

        except requests.exceptions.HTTPError as err:
            print(f"HTTP error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"HTTP error occurred: {err}")
        
        except Exception as err:
            print(f"An error occurred: {err}")
            self.bot.sendMessage(chat_ID, text=f"An error occurred: {err}")

    def display_sensor_data(self, chat_ID, sensor_type):
        # Retrieve the ThingSpeak iframe URL for the selected sensor type
        iframe_url = self.get_thingspeak_iframe_url(sensor_type)
        
        # Send the iframe URL to the user
        self.bot.sendMessage(chat_ID, text=f"Here is the plot for {sensor_type}:\n{iframe_url}")
        
        # Suggest further commands to the user
        self.bot.sendMessage(chat_ID, text='Write /operation to ask for data, /new_owner to create a new owner, /delete_owner to remove it, /new_user to add a new user, /delete_user to remove it')

    def get_owner_index(self):
        for i, room in enumerate(self.list_owners):
            if room == self.requested_owner:
                return i + 1
        return 0

    def get_thingspeak_iframe_url(self, sensor_type):
        # Retrieve the ThingSpeak channel ID for the selected owner
        channel_id = self.get_channel_id()
        
        # Handle the case where no channel ID is found
        if not channel_id:
            return "Error: Channel ID not found. Please create it using the ThingSpeak.py script before proceeding."
        
        # Mapping sensor types to their respective ThingSpeak field numbers
        sensor_map = {
            'temperature': '1',
            'humidity': '2',
            'noise': '3',
            'brightness': '4'
        }
        
        # Determine the field number for the selected sensor type
        field_number = sensor_map.get(sensor_type, '1')
        
        # Construct the iframe URL for the ThingSpeak chart
        return (f'https://thingspeak.com/channels/{channel_id}/charts/{field_number}'
            f'?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&type=line'
            f'&width=1200&height=800&autoscale=true&margin=auto&border=0')
        
    def get_channel_id(self):
        try:
            # Send a request to the ThingSpeak API to retrieve the list of channels
            response = requests.get(self.thingspeak_url, params={'api_key': self.api_key})
            response.raise_for_status()
            
            # Parse the JSON response to get the list of channels
            channels = response.json()
            
            # Search for the channel that matches the requested owner's name
            if channels:
                for channel in channels:
                    if channel['name'] == self.requested_owner:
                        return channel['id']  # Return the channel ID if found
        except requests.RequestException as e:
            print(f"Error fetching channel ID: {e}")  # Log any request errors
        return None  # Return None if no channel ID was found
    
    def create_TS_channel(self, chat_ID):
        # Creazione canale dando in input nome del nuovo canale = nome owner
        request_string = f"http://{self.ip_address}:{self.ip_port}/thingspeak/create_channel" #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        data = {
            'owner': self.name_new_owner
        }
        # Check if the response status code indicates success
        try:
            response = requests.post(request_string, json=data)
            response = response.json()
            # Assuming response_json contains some useful info about the channel creation
            self.bot.sendMessage(chat_ID, text="New Thingspeak channel successfully created.")
        except:
            # Handle non-200 responses
            self.bot.sendMessage(chat_ID, text=f"Failed to create Thingspeak channel. Status code: {response.status_code}")

        channel_ID = response["channel_id"]
        self.channel_ID = channel_ID
        write_key = response["write_key"]
        print('Channel:', channel_ID)
        print('Write_key: ', write_key)
        
        # Salvataggio dati del thingspeak nel resource catalog
        request_string = f"{resource_catalog_url}/thingspeak"
        headers = {'Content-Type': 'application/json'}
        json_body = {
            "device_connector_ID": self.name_new_owner,
            "channel_id": channel_ID,
            "write_key": write_key,
            "read_key": self.api_key
        }
        response = requests.post(request_string, json=json_body, headers=headers)
        
    def delete_TS_channel(self, chat_ID):
        print('Eliminazione canale TS')
        get_string = f"{resource_catalog_url}/thingspeak?device_connector_ID={self.name_delete_owner}"
        response = requests.get(get_string)
        output = response.json()
        channel_id = output["channel_id"]
        
        # Eliminazione canale dal resource catalog 
        delete_string_rc = f"{resource_catalog_url}/thingspeak?channel_id={channel_id}"
        
        # Eliminazione canale da Thingspeak
        delete_string = f"http://{self.ip_address}:{self.ip_port}/thingspeak/delete_channel?channel_id={channel_id}"
        
        # Check if the response status code indicates success
        try:
            response = requests.delete(delete_string)
            response = response.json()
            response_rc = requests.delete(delete_string_rc)
            response_rc = response_rc.json()
            # Assuming response_json contains some useful info about the channel creation
            self.bot.sendMessage(chat_ID, text="Thingspeak channel successfully deleted.")
        except:
            # Handle non-200 responses
            self.bot.sendMessage(chat_ID, text=f"Failed to delete Thingspeak channel")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Carica le informazioni dal file JSON del catalogo di servizio
    service_catalog_info_name = "settings_service_catalog.json"
    service_catalog_info = load_json_file(service_catalog_info_name)

    # Seleziona il resource catalog
    res_catalog_info = get_resource_catalog(service_catalog_info)
    print(f"Resource catalog: {res_catalog_info} \n")
    
    telegram_catalog_info_path = os.path.join(current_dir, "conf_telegram.json")
    with open(telegram_catalog_info_path, "r") as file:
        conf_telegram_file_json = json.load(file)
    token = conf_telegram_file_json["telegramToken"]
    
    # Registrazione nel service catalog del servizio Telegram
    post_string = f'{service_catalog_url}/microservice'
    response = requests.post(post_string, json.dumps(conf_telegram_file_json))

    # Estrazione info ThingSpeak
    get_string = f'{service_catalog_url}/microservice_info?name_microservices=thingspeakREST'
    response = requests.get(get_string)
    info_TS = json.loads(response.text)
    ip_address = info_TS["ip_address"]
    ip_port = info_TS["ip_port"]
    api_key = info_TS['key']
    thingspeak_url = info_TS['url_channels']
    
    bot = EchoBot1(token, service_catalog_info, res_catalog_info, ip_address, ip_port, api_key, thingspeak_url)
    
    print("Bot started ...")
    while True:
        time.sleep(3)
