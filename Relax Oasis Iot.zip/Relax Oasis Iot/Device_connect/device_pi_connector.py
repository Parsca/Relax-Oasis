import json
import os
import requests
from MyMQTT import *
from simplePublisher import *
from simpleSubscriber import *
import sys
import numpy as np
import threading
import random
import time
from utils import (
    load_json_file,
    get_resource_catalog,
    get_owners,
    get_owners_DC,
    select_owner,
)
service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')


def registration(service_catalog_info, res_catalog_info, conf_file_sensors, sensor_data, name_owner, newDC):
    clientID = name_owner
    
    rc_ip = res_catalog_info["ip_address"]
    rc_ip_port = res_catalog_info["ip_port"]
    rc_basetopic = res_catalog_info["base_topic"]
    rc_broker = res_catalog_info["broker"]
    rc_port = res_catalog_info["broker_port"]

    # info about base topic
    request_string = f"{service_catalog_url}/base_topic"
    response = requests.get(request_string)
    service_b_t = json.loads(response.text)
    
    sensors = []
    topic_sensors = []
    
    # Iterate over the dictionary to access both keys and values
    for sensor_type, sensor_count in sensor_data.items():
        #print(f"{sensor_type}: {sensor_count}")
        topic_subscribe_alert = f"{service_b_t}/microservice/actuator/#"

        conf = conf_file_sensors['conf_file']
        for sensor in conf:
            if sensor_type == sensor['sensor_type'][0]:
                for i in range(1,sensor_count+1):
                    single_sensor = {
                        "sensor_id": sensor['sensor_id'] + '_' + str(i),
                        "sensor_type": sensor['sensor_type'][0],
                        "measure": sensor['measure'][0],
                                }
                    topic = f"{service_b_t}{rc_basetopic}/sensor_value/{name_owner}/{sensor_type}/{sensor['sensor_id'] + '_' + str(i)}"
                    sensors.append(single_sensor)
                    topic_sensors.append(topic)
    
    actuator = {"sensor_id": 'actuator'}
    topic_actuator = f"{service_b_t}{rc_basetopic}/actuator/{name_owner}" 
    topic_publish = f"{service_b_t}{rc_basetopic}/sensor_value/{name_owner}"       
    complete_topic = topic_sensors + [topic_actuator]
                
    output = {
            "device_connector_ID": name_owner,
            "sensors": [sensors],
            "actuators": [actuator],
            "end-points": 
                        {
                            "basetopic": service_b_t,
                            "complete_topic": complete_topic,
                            "broker": res_catalog_info["broker"],
                            "port": res_catalog_info["broker_port"]
                        },
            "insert-timestamp": time.time(),
        }
    
    if newDC:
        # add new Device Connector to resource catalog
        post_string = f'http://{rc_ip}:{rc_ip_port}/deviceConnector'
        response = requests.post(post_string, json=output)
    else:
        # update new Device Connector to resource catalog
        put_string = f'http://{rc_ip}:{rc_ip_port}/deviceConnector'
        response = requests.put(put_string, json=output)
    
    return output, clientID, rc_broker, rc_port, topic_sensors, topic_publish, topic_actuator, topic_subscribe_alert

# -----------------------------------------------------------------------------------------#
class Device(MyPublisher, MySubscriber):
    def __init__(self, clientID, broker, port, topic_publish, topic_subscribe, topic_subscribe_alert):
        self.clientID = clientID
        self.topic_publish = topic_publish
        self.topic_subscribe = topic_subscribe
        self.topic_subscribe_alert = topic_subscribe_alert

        # Configura il client MQTT per il publishing e la sottoscrizione
        self.client = MyMQTT(self.clientID, broker, port, self)

        self.__message = {
            'bn': self.topic_publish,
            'e': [
                {
                    'type': '',
                    'unit': '',
                    'timestamp': '',
                    'value': ' '
                }
            ]
        }

    def start(self):
        self.client.start()
        if self.topic_subscribe_alert:
            self.client.mySubscribe(self.topic_subscribe_alert)
            print(f'Started subscription to {self.topic_subscribe}')

    def stop(self):
        self.client.stop()

    def publish(self, value, sensor_type, sensor_name, unit):
        self.publish_topic = self.topic_publish +'/'+sensor_type+'/'+sensor_name
        message = self.__message
        message['bn'] = self.publish_topic
        message['e'][0]['type'] = sensor_type
        message['e'][0]['value'] = value
        message['e'][0]['unit'] = unit
        message['e'][0]['timestamp'] = str(time.time())
        self.client.myPublish(self.publish_topic, json.dumps(message))
        #print("Published\n" + json.dumps(message))

    def notify(self, topic, msg):
        message = json.loads(msg)
        print(message)
        payload = message['e']
        try:
            print(payload[0]['value'])
        except:
            pass
        
        if "safe_occupancy" in topic:
            for element in payload:
                if element["type"] == 'safe_occupancy':
                    safe_occupancy = element["value"]
                elif element["type"] == 'people_inside':
                    people_inside = element["value"]
            if safe_occupancy is None:
                print('We are sorry, but you are NOT authorized! \nYou can contact the manager room in order to be registered through TelegramBot')
            elif safe_occupancy <= people_inside + 1: 
                print('We are sorry, but the RelaxRoom is full! Come back later...')
            else:
                print(f'You can enter and enjoy the RelaxRoom experience!')
            print()
        elif "alert" in topic:
            alert_message = payload[0]["value"]
            print(alert_message)
            

# -----------------------------------------------------------------------------------------#

def simulate_data(sensor_type, sensor_name):
    if sensor_type == 'fiscal_code': 
        simulated_list_CF = ['user_1', 'user_2', 'user_3', 'user_4', 'user_5']
        unit = 'string'
        publish_fiscal_code(simulated_list_CF, sensor_type, sensor_name, unit)
    else:
        if sensor_type == 'temperature':
            a = 15
            b = 38
            unit = 'celsius'
        elif sensor_type == 'humidity': 
            a = 0
            b = 100
            unit = 'percentage'
        elif sensor_type == 'noise': 
            a = 0
            b = 80
            unit = 'dB'
        elif sensor_type == 'brightness': 
            a = 100
            b = 3000  
            unit = 'lm'    
        
        while True:
            mean = (a + b) / 2  
            std = (b - a) / 6  

            # Causal values with gaussian distribution
            simulated_level = round(np.random.normal(mean, std), 3)

            print()
            print(f'{sensor_type} simulated Level = {simulated_level:0.1f}')
            Sensor.publish('{0:0.1f}'.format(simulated_level), sensor_type, sensor_name, unit)

            time.sleep(15)

def publish_fiscal_code(simulated_list_CF, sensor_type, sensor_name, unit):       
    while True:
        index = random.randint(0, len(simulated_list_CF) - 1)
        simulated_CF = simulated_list_CF[index]
        print('------------------------------')
        print(f'Simulated CF = {simulated_CF}')
        Sensor.publish(f'{simulated_CF}', sensor_type, sensor_name, unit)
        print()
        time.sleep(20)

if __name__ == "__main__":
    # Carica le informazioni dal file JSON del catalogo di servizio
    service_catalog_info_name = "settings_service_catalog.json"
    service_catalog_info = load_json_file(service_catalog_info_name)

    # Seleziona il resource catalog
    res_catalog_info = get_resource_catalog(service_catalog_info)
    print(f"Resource catalog: {res_catalog_info} \n")

    # Seleziona gli owners
    newDC = True
    list_owners = get_owners(res_catalog_info)
    name_owner, number_owner = select_owner(list_owners)
    print(f"Selected owner: {name_owner} \n")
    
    list_ownersDC = get_owners_DC(res_catalog_info)
    if name_owner in list_ownersDC:
        print(f'This RelaxRoom already has a DevicePi Connector associated with {name_owner}.')
        while True:
            update_DC = input('Do you want to update the number of sensors connected to the DevicePi Connector? (y/n): ').lower()
            if update_DC == 'n':
                print("No updates will be made. Exiting.")
                sys.exit()  # O interrompere il flusso in modo più pulito, senza sys.exit()
            elif update_DC == 'y':
                print("Proceeding with DevicePi Connector update...")
                newDC = False
                break
            else:
                print("Invalid input. Please enter 'y' for yes or 'n' for no.")
        
    conf_file_sensors = load_json_file("conf_sensors.json")
    # Ask the user for the number of sensors for each category
    try:
        num_temperature_sensors = int(input("How many temperature sensors do you want to run? "))
        num_humidity_sensors = int(input("How many humidity sensors do you want to run? "))
        num_brightness_sensors = int(input("How many light sensors do you want to run? "))
        num_noise_sensors = int(input("How many noise sensors do you want to run? "))
        num_fiscal_code_sensors = int(input("How many room access sensors do you want to run? "))

        # Save the sensor values in a dictionary
        sensor_data = {
            "temperature": num_temperature_sensors,
            "humidity": num_humidity_sensors,
            "brightness": num_brightness_sensors,
            "noise": num_noise_sensors,
            "fiscal_code": num_fiscal_code_sensors
        }      

    except ValueError:
        print("Please enter a valid number for each type of sensor.")

    output, clientID, rc_broker, rc_port, topic_sensors, topic_publish, topic_actuator, topic_subscribe_alert = registration(service_catalog_info, res_catalog_info, conf_file_sensors, sensor_data, name_owner, newDC)
    
    # Inizializza l'istanza del device come publisher e subscriber
    Sensor = Device(clientID, rc_broker, rc_port, topic_publish, topic_actuator, topic_subscribe_alert)
    Sensor.start()
    
    for topic in topic_sensors:
        parts = topic.split('/')
        sensor_type = parts[-2]
        sensor_name = parts[-1]

        # Avvia il thread per simulare i dati sulla luminosità (o altri tipi di dati)
        simulate_thread = threading.Thread(target=simulate_data, args=(sensor_type, sensor_name))
        simulate_thread.start()
