import json
import cherrypy
import requests
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')

class ResourceCatalogManager(object):
    def __init__(self, service_file, setting_file, devices_file):   
        self.service_file = service_file  # service_file = "settings_service_catalog.json"
        self.service_info = json.load(open(self.service_file))
        self.settingsFile = setting_file  # setting_file = "settings_resource_catalog.json"
        self.settings = json.load(open(self.settingsFile))
        self.resourceFile = devices_file  # devices_file = "resource_catalog.json"
        self.resource = json.load(open(self.resourceFile))
        
        # Add info about owner (resource_catalog_settings) in service_catalog_info
        poststring = f"{service_catalog_url}/resource"
        self.settings["name_resource_catalog"] = devices_file
        requests.post(poststring, json.dumps(self.settings))

    exposed = True
    def find_entry(self, collection, key, value):
        # Handle collections of dictionaries or strings
        if isinstance(collection, list) and len(collection) > 0:  # Check if list is not empty
            if isinstance(collection[0], dict):
                for entry in collection:
                    if entry.get(key) == value:
                        return entry
            elif isinstance(collection[0], str) and key == "owner":
                return value in collection
        return None

    def GET(self, *uri, **parameters):
        if len(uri) == 1 and len(parameters) < 3:
            if uri[0] == 'base_topic':
                return json.dumps(self.settings["base_topic"])
            
            if uri[0] == "alldevices":
                owner = parameters.get("owner", None)
                return self.viewAllDevices(owner)  # Updated to reflect new viewAllDevices function
                
            elif uri[0] == "allusers":
                owner = parameters.get("owner", None)
                return self.viewAllUsers(owner)
            
            elif uri[0] == "allowners":
                return self.viewAllOwners()  # Ensure viewAllOwners is updated accordingly
            
            elif uri[0] == "allownersDC":
                return self.viewAllOwnersDC()  # Ensure viewAllOwnersDC is defined
            
            elif uri[0] == "allownersWithoutDC":
                return self.viewAllOwnersWithoutDC()  # Ensure viewAllOwnersWithoutDC is defined
            
            elif uri[0] == "allSensorTypes":
                owner = parameters.get("owner", None)
                return self.viewAllSensorTypes(owner)  # Ensure viewAllOwnersWithoutDC is defined
            
            elif uri[0] == "registeredUser":
                user_id = parameters.get("user_ID")
                owner = parameters.get("owner", None)
                print(user_id, owner)
                output = self.checkRegisteredUser(user_id, owner)
                return output

            elif uri[0] == "device":
                owner = parameters.get("owner")
                ID = parameters.get("ID")
                if owner and ID:
                    result = self.searchDevicesByDeviceOwner_ID(owner, ID)
                    if result is not None:
                        return json.dumps({"status": "error", "message": "Device already registered or owner/ID not registered"})
                    else:
                        return json.dumps({"status": "success", "message": "Device NOT registered"})
                else:
                    return json.dumps({"status": "error", "message": "Owner/ID parameter is missing"})
        
            elif uri[0] == "thingspeak":
                device_connector_ID = parameters.get("device_connector_ID")
                print(device_connector_ID)
                for thing in self.resource['thingspeak']:
                    if thing.get('device_connector_ID') == device_connector_ID:
                        print('TS channel registrated')
                        return json.dumps(thing)
                return None
            
            elif uri[0] =="thingspeakConfig":
                try:
                    # Prepara le configurazioni ThingSpeak
                    thingspeak_configs = {}
                    for ts_channel in self.resource.get('thingspeak', []):
                        device_connector_id = ts_channel.get("device_connector_ID")
                        if device_connector_id:
                            thingspeak_configs[device_connector_id] = {
                                "channel_id": ts_channel.get("channel_id", None),
                                "write_key": ts_channel.get("write_key", ts_channel.get("api_key", None))
                            }
                    # Restituisci la risposta JSON con le configurazioni elaborate
                    return json.dumps(thingspeak_configs)
                except (FileNotFoundError, json.JSONDecodeError) as e:
                    cherrypy.response.status = 500
                    return {"error": str(e)}  
    
    def POST(self, *uri, **parameters):
        if len(uri) == 1:
            body = cherrypy.request.body.read()
            json_body = json.loads(body)
            
            if uri[0] == "device":
                owner = json_body.get("owner")
                ID = json_body.get("sensor", [{}])[0].get("sensor_id")
                
                if not owner:
                    raise cherrypy.HTTPError(400, "Owner parameter is missing")
                
                if self.searchDevicesByDeviceOwner_ID(owner, ID):
                    raise cherrypy.HTTPError(400, "Device already present")
                else:
                    self.insertDevice(json_body)
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "Device successfully added"})
            
            elif uri[0] == "deviceConnector":
                self.insertDevice(json_body)
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "Device connector successfully added"})
            
            elif uri[0] == "user":
                user_id = json_body.get("user_ID")
                owner = json_body.get("room_authorization")[0]
                if not user_id:
                    raise cherrypy.HTTPError(400, "User ID parameter is missing")
                
                if self.searchUserByUserID(user_id, owner):
                    cherrypy.response.status = 409  # HTTP status code 409 Conflict
                    return json.dumps({"error": "User already registered"})
                
                self.insertUser(json_body)
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "User successfully added"})
            
            elif uri[0] == "owner":
                owner = json_body.get("owner")
                
                if not owner:
                    raise cherrypy.HTTPError(400, "Owner parameter is missing")
                
                if self.find_entry(self.resource["registered_owners"], "owner", owner):
                    raise cherrypy.HTTPError(409, "Owner already present")
                
                self.insertOwner(owner)
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "Owner successfully added"})
            
            elif uri[0] == "thingspeak":
                self.insertTS(json_body)
    
    def PUT(self, *uri, **parameters):
        if len(uri) == 1:
            body = cherrypy.request.body.read()
            json_body = json.loads(body)
            
            if uri[0] == "deviceConnector":
                device_connector_id = json_body.get("device_connector_ID")
                if not device_connector_id:
                    raise cherrypy.HTTPError(400, "Missing device_connector_ID in request body")
                # Remove the old device and insert the updated one
                self.removeDevice(device_connector_id)
                self.insertDevice(json_body)
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "Device connector successfully updated"})
            
            elif uri[0] == "device":
                owner = json_body.get("owner")
                ID = json_body.get("sensor", [{}])[0].get("sensor_id")
                
                if not owner or not ID:
                    raise cherrypy.HTTPError(400, "Missing owner or sensor_id in request body")
                
                if not self.validateDevice(json_body):
                    raise cherrypy.HTTPError(400, "Invalid device data structure")
                
                if self.searchDevicesByDeviceOwner_ID(owner, ID):
                    self.updateDeviceInfo(json_body, owner)
                else:
                    self.insertDevice(json_body)
                
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "Device successfully updated or added"})
            
            elif uri[0] == "userUpdate":
                userToUpdate = json_body
                self.updateUserInfo(userToUpdate)
                
            elif uri[0] == "userAuthorizationUpdate":
                user_ID = json_body["user_ID"]
                new_authorizations = json_body["room_authorization"]
                self.updateUserRoomAuthorization(user_ID, new_authorizations)
            
            elif uri[0] == "user":
                user_id = json_body.get("user_ID")
                owner = json_body.get("room_authorization", [None])[0]
                
                if not user_id or not owner:
                    raise cherrypy.HTTPError(400, "Missing user_ID or room_authorization in request body")
                
                if self.searchUserByUserID(user_id, owner):
                    self.updateUserInfo(json_body)
                else:
                    self.insertUser(json_body)
                
                # Ricarica le risorse dal file
                self.resource = json.load(open(self.resourceFile))
                return json.dumps({"message": "User successfully updated or added"})
            
            else:
                raise cherrypy.HTTPError(400, "Invalid URI")
        else:
            raise cherrypy.HTTPError(400, "Incorrect URI or PARAMETERS")


    def DELETE(self, *uri, **parameters):
        if len(uri) == 1:
            if uri[0] == "device":
                device_connector_id = parameters.get("device_connector_ID")
                if device_connector_id:
                    if self.removeDeviceAndAuthorization(device_connector_id):
                        return json.dumps({"status": "success", "message": "Device removed"})
                    else:
                        return json.dumps({"status": "error", "message": "Device not found"})
                else:
                    raise cherrypy.HTTPError(400, "device_connector_ID parameter is missing")
                    
            elif uri[0] == "user":
                user_id = parameters.get("user_id")
                if user_id:
                    if self.removeUser(user_id):
                        return json.dumps({"status": "success", "message": "User removed"})
                    else:
                        return json.dumps({"status": "error", "message": "User not found"})
                else:
                    raise cherrypy.HTTPError(400, "user_id parameter is missing")

            elif uri[0] == "owner":
                owner = parameters.get("owner")
                if owner:
                    if self.removeOwner(owner):
                        return json.dumps({"status": "success", "message": "Owner removed"})
                    else:
                        return json.dumps({"status": "error", "message": "Owner not found"})
                else:
                    raise cherrypy.HTTPError(400, "Owner parameter is missing")
            
            elif uri[0] == "thingspeak":
                channel_id = parameters.get("channel_id")
                if channel_id:
                    print(channel_id)
                    if self.removeTS(channel_id):
                        return json.dumps({"status": "success", "message": f"Channel {channel_id} removed"})
                    else:
                        return json.dumps({"status": "error", "message": "Channel not found"})
                else:
                    raise cherrypy.HTTPError(400, "Channel ID parameter is missing")
            else:
                raise cherrypy.HTTPError(400, "Incorrect URI or PARAMETERS")
        else:
            raise cherrypy.HTTPError(400, "Incorrect URI or PARAMETERS")

    
    def viewAllDevicesID(self):
        device_ids = [device["device_connector_ID"] for device in self.resource["devices"]]
        return json.dumps(device_ids)
    
    def viewAllDevices(self):
        return json.dumps(self.resource["devices"])

    def viewAllUsers(self, owner=None):
        list_users = []
        
        if owner:
            # If an owner is specified, find users associated with that owner
            if owner in self.resource["registered_owners"]:
                for device in self.resource["devices"]:
                    if device["device_connector_ID"] == owner:
                        list_users.extend(device.get("users", []))
        else:
            # If no owner is specified, return all registered users
            list_users = self.resource["registered_users"]
        
        return json.dumps(list_users, indent=4)
    
    def viewAllOwners(self):
        return json.dumps(self.resource["registered_owners"])
    
    def viewAllOwnersDC(self):
        return json.dumps([device['device_connector_ID'] for device in self.resource['devices']])
    
    def viewAllOwnersWithoutDC(self):
        registeredOwners = self.resource["registered_owners"]
        registeredOwnersDC = [device['device_connector_ID'] for device in self.resource['devices']]
        owners_only_in_registeredOwners = list(set(registeredOwners) - set(registeredOwnersDC))
        return json.dumps(owners_only_in_registeredOwners)
    
    def viewAllSensorTypes(self, device_connector_ID):
        sensor_types = set() 
        for device in self.resource['devices']:
            if device['device_connector_ID'] == device_connector_ID:
                for sensor_group in device['sensors']:
                    for sensor in sensor_group:
                        sensor_types.add(sensor['sensor_type'])
        result = {
            "device_connector_ID": device_connector_ID,
            "sensor_types": list(sensor_types)
        }
        return json.dumps(result, indent=4)

    def checkRegisteredUser(self, ID, room_ID=None):
        # Check if the user is registered without considering room_ID
        user_registered = any(user["user_ID"] == ID for user in self.resource["registered_users"])
        
        if room_ID:
            # If room_ID is provided, check if the user is registered in that specific room
            for user in self.resource["registered_users"]:
                if user["user_ID"] == ID and room_ID in user["room_authorization"]:
                    return json.dumps({"error": "User already registered in the specified room"})
            # If user is not registered in the specified room
            if user_registered:
                return json.dumps({"status": "success", "message": "User registered but not in the specified room"})
        else:
            # If room_ID is not provided, just check if the user is registered
            if user_registered:
                return json.dumps({"error": "User already registered"})
        return json.dumps({"status": "success", "message": "User NOT registered"})

    def checkTSChannels(self, owner):
        # Check if the owner is registered
        if owner not in self.resource["registered_owners"]:
            return False
        
        # Check for the specified owner's devices and their ThingSpeak channels
        for device in self.resource["devices"]:
            if device["device_connector_ID"] == owner:
                return len(device.get("thingspeak", [])) == 0
        
        return False
    
    def extractOwner(self, body):
        return body.get("owner")
    
    def extractID(self, body):
        return body.get("sensor", [{}])[0].get("sensor_id")
    
    def searchDevicesByDeviceOwner_ID(self, owner, sensor_id):
        # Search for the device owned by the given owner
        for device in self.resource["devices"]:
            if device["device_connector_ID"] == owner:
                # Search for the sensor within the device
                for sensor in device.get("sensors", []):
                    if sensor["sensor_id"] == sensor_id:
                        return sensor
        return None
    
    def searchUserByUserID(self, user_id, owner):
        # Check if the owner is in the registered owners list
        if owner in self.resource["registered_owners"]:
            # Search for the user in the registered_users list
            for user in self.resource["registered_users"]:
                if user["user_ID"] == user_id:
                    # Check if the user has authorization for the specified owner
                    if owner in user.get("room_authorization", []):
                        return user
        return None

    
    def searchOwner(self, new_owner):
        return new_owner if new_owner in self.resource["registered_owners"] else None
    
    def updateDeviceInfo(self, deviceToUpdate, owner):
        new_sensors = deviceToUpdate.get("sensor", [])
        device_updated = False
        for device_entry in self.resource["devices"]:
            if device_entry["owner"] == owner:
                updated_sensors = set()
                for new_sensor in new_sensors:
                    sensor_found = False
                    for i, sensor in enumerate(device_entry.get("sensors", [])):
                        if sensor["sensor_id"] == new_sensor["sensor_id"]:
                            device_entry["sensors"][i] = new_sensor
                            sensor_found = True
                            break
                    if not sensor_found:
                        device_entry["sensors"].append(new_sensor)
                        device_updated = True
                        updated_sensors.add(new_sensor["sensor_id"])
                
                # Remove sensors that are no longer in the updated list
                device_entry["sensors"] = [sensor for sensor in device_entry.get("sensors", []) if sensor["sensor_id"] in updated_sensors]
                if device_updated:
                    with open(self.resourceFile, "w") as file:
                        json.dump(self.resource, file, indent=4)
                return
    
    def updateUserInfo(self, userToUpdate):
        print('MODIFICA DATI USER')
        user_ID = userToUpdate["user_ID"]
        # Check if the user is already in the registered_users list
        for user in self.resource["registered_users"]:
            if user["user_ID"] == user_ID:
                self.resource["registered_users"].remove(user)
        
        # Add the user to the registered_users list
        self.resource["registered_users"].append(userToUpdate)
        with open(self.resourceFile, "w") as file:
            json.dump(self.resource, file, indent=4)

    def insertUser(self, userToInsert):
        user_ID = userToInsert["user_ID"]
        # Check if the user is already in the registered_users list
        for user in self.resource["registered_users"]:
            if user["user_ID"] == user_ID:
                print(f"User {user_ID} already registered.")
                return
        # Add the user to the registered_users list
        self.resource["registered_users"].append(userToInsert)
        with open(self.resourceFile, "w") as file:
            json.dump(self.resource, file, indent=4)
    
    def insertDevice(self, deviceToInsert):
        print('Inserting  device connector:', deviceToInsert["device_connector_ID"])
        for device in self.resource["devices"]:
            if device["device_connector_ID"] == deviceToInsert["device_connector_ID"]:
                break
        self.resource["devices"].append(deviceToInsert)
        with open(self.resourceFile, "w") as file:
            json.dump(self.resource, file, indent=4)
    
    def insertOwner(self, owner):
        if owner not in self.resource["registered_owners"]:
            self.resource["registered_owners"].append(owner)
            with open(self.resourceFile, "w") as file:
                json.dump(self.resource, file, indent=4)

    def insertTS(self, channelInfo):
        # Trova il dispositivo per ID
        self.resource["thingspeak"].append(channelInfo)
        # Save the updated devices list to the file
        with open(self.resourceFile, "w") as file:
            json.dump(self.resource, file, indent=4)
    
    def removeTS(self, channelID):
        # Trova l'indice del canale con l'ID corrispondente
        found = False
        for channel in self.resource["thingspeak"]:
            if channel.get("channel_id") == channelID:
                self.resource["thingspeak"].remove(channel)
                print('Found :', channelID)
                found = True
                break
        if found:
            # Salva l'elenco aggiornato nel file
            with open(self.resourceFile, "w") as file:
                json.dump(self.resource, file, indent=4)
            return {"status": "Success", "message": f"Channel {channelID} removed successfully"}
        else:
            return {"status": "Error", "message": f"Channel {channelID} not found"}

    
    def removeUser(self, user_id):
        # Remove user from registered_users
        initial_length = len(self.resource["registered_users"])
        self.resource["registered_users"] = [
            user for user in self.resource["registered_users"]
            if user["user_ID"] != user_id
        ]
        # Check if the user was found and removed
        if len(self.resource["registered_users"]) < initial_length:
            # Save changes to the JSON file
            with open(self.resourceFile, "w") as file:
                json.dump(self.resource, file, indent=4)
            return True
        return False
    
    def removeDevice(self, device_connector_id):
        # Print the device_connector_id being removed for debugging
        print('Removing device connector:', device_connector_id)
        # Remove the device with the specified device_connector_ID
        self.resource["devices"] = [
            device for device in self.resource["devices"]
            if device["device_connector_ID"] != device_connector_id
        ]
        # Save the updated devices list to the file
        with open(self.resourceFile, "w") as file:
            json.dump(self.resource, file, indent=4)

    def removeDeviceAndAuthorization(self, device_connector_id):
        # Rimuovi il dispositivo con l'ID specificato
        print('Removing:' ,device_connector_id)
        
        # Rimozione del dispositivo dalla lista dei dispositivi
        self.resource["devices"] = [device for device in self.resource["devices"] if device["device_connector_ID"] != device_connector_id]
            
        # Rimozione del device_connector_id dalla lista room_authorization degli utenti
        for user in self.resource["registered_users"]:
            if device_connector_id in user.get("room_authorization", []):
                print('Rimozione device')
                user["room_authorization"].remove(device_connector_id)
                with open(self.resourceFile, "w") as file:
                    json.dump(self.resource, file, indent=4)
        # Rimozione owner dalla lista degli owner
        print(self.resource["registered_owners"])
        if device_connector_id in self.resource["registered_owners"]:
            print('OK')
            # Rimuovi l'elemento dalla lista
            self.resource["registered_owners"].remove(device_connector_id)
            with open(self.resourceFile, "w") as file:
                json.dump(self.resource, file, indent=4)
            return True
        else:
            return False

    def removeOwner(self, owner):
        if owner in self.resource["registered_owners"]:
            self.resource["registered_owners"].remove(owner)
            self.resource["devices"] = [device for device in self.resource["devices"] if device["owner"] != owner]
            with open(self.resourceFile, "w") as file:
                json.dump(self.resource, file, indent=4)
            return True
        return False
    
    def updateUserRoomAuthorization(self, user_ID, new_authorizations):
        # Check if the user exists in the registered_users list
        for user in self.resource["registered_users"]:
            if user["user_ID"] == user_ID:
                # Aggiungi le nuove autorizzazioni senza duplicare quelle già esistenti
                current_authorizations = user.get("room_authorization", [])
                updated_authorizations = list(set(current_authorizations + new_authorizations))
                
                # Aggiorna la lista delle autorizzazioni
                user["room_authorization"] = updated_authorizations
                
                # Salva le modifiche nel file
                with open(self.resourceFile, "w") as file:
                    json.dump(self.resource, file, indent=4)
                
                print(f"User {user_ID}'s room authorizations updated.")
                return
        
        # Se l'utente non viene trovato
        print(f"User {user_ID} not found.")


if __name__ == "__main__":
    service_file = "settings_service_catalog.json"
    setting_file = "settings_resource_catalog.json" 
    devices_file = "catalog_resource.json" 

    conf = {
        "/": {
            "request.dispatch": cherrypy.dispatch.MethodDispatcher(),
            "tools.sessions.on": True,
        }
    }
    settings = json.load(open(setting_file))
    
    rcm = ResourceCatalogManager(service_file, setting_file, devices_file)
    cherrypy.tree.mount(rcm, "/", conf)
    cherrypy.config.update(conf)
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.config.update({"server.socket_port": int(settings["ip_port"])})
    cherrypy.engine.start()
    # while True:
    #     rcm.removeDevices()
    #     time.sleep(120)
    cherrypy.engine.block()