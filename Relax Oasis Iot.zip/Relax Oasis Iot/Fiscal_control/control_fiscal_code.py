import paho.mqtt.client as PahoMQTT
import time
import json
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import warnings
import requests
import json
import requests
from MyMQTT import *
from simplePublisher import *
from simpleSubscriber import *
import requests
import sys
import numpy as np
import threading
import sys
import random
from utils import (
    load_json_file,
    get_resource_catalog
)
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')


class ML:
		def __init__(self, clientID, topic, publish_topic, broker, port, rc_ip, rc_ip_port):
			self.clientID = clientID
			# create an instance of paho.mqtt.client
			self._paho_mqtt = PahoMQTT.Client(clientID, True) 

			# register the callback
			self._paho_mqtt.on_connect = self.myOnConnect
			self._paho_mqtt.on_message = self.myOnMessageReceived

			self.topic = topic
			self.publish_topic = publish_topic
			self.messageBroker = broker 
			self.port = int(port)

			self.authorized = False
			self.received_humidity = False
			self.received_temperature = False
			self.received_CF = False

			self.rc_ip = rc_ip
			self.rc_ip_port = rc_ip_port

			self.model = self.train_model()

			self.temperature = None
			self.humidity = None
			self.people_inside = 10
			self.fixed_number_people = 18

			self.predicted_occupancy = 0  
                    
			self.message = {
							"e": [
								{
									"type": "safe_occupancy",
									"value": int(self.predicted_occupancy),
									"timestamp": time.time()
								}
							]
						}

		def start (self):
			# manage connection to broker
			self._paho_mqtt.connect(self.messageBroker, self.port)
			self._paho_mqtt.loop_start()
			# subscribe for a topic
			self._paho_mqtt.subscribe(self.topic, 0)

		def stop (self):
			self._paho_mqtt.unsubscribe(self.topic)
			self._paho_mqtt.loop_stop()
			self._paho_mqtt.disconnect()

		def myOnConnect (self, paho_mqtt, userdata, flags, rc):
			# print ("Connected to %s with result code: %d" % (self.messageBroker, rc))
			# print ("Connected with topic %s " % (self.topic))
			pass

		def myOnMessageReceived (self, paho_mqtt , userdata, msg):
			# A new message is received
			# print ("Topic:'" + msg.topic+"', QoS: '"+str(msg.qos)+"' Message: '"+str(msg.payload) + "'")
			topic = msg.topic
			message_json = json.loads(msg.payload)
			self.owner = topic.split('/')[3]
			if 'fiscal_code' not in topic:
				if 'mean_value' in topic:
					if 'temperature' in topic:
						self.temperature =  message_json["e"][0]["value"]
						self.received_temperature =  True
					elif 'humidity' in topic:
						self.humidity =  message_json["e"][0]["value"]
						self.received_humidity =  True
			elif 'fiscal_code' in topic and 'safe_occupancy' not in topic:
				if not self.received_humidity or not self.received_temperature:
					print('Waiting for RelaxRoom measurements (temperature/humidity)')
				else:
					self.received_CF =  message_json["e"][0]["value"]
					print()
					print()
					print()
					print('***************************************************************')
					print('Evaluating if subject ', self.received_CF,' is authorized...')
					time.sleep(1.5)
					try:
						get_string = f'{resource_catalog_url}/registeredUser?user_ID={self.received_CF}&owner={self.owner}'
						response = requests.get(get_string)
						output = response.json()
						try:
							message = output["error"]
							if message == 'User already registered in the specified room':
								print(f"User registered with ID: {self.received_CF} in {self.owner}.")
								print()
								time.sleep(1)
							self.authorized = True
						except:
							print('User NOT authorized to enter')
							print()
							response.raise_for_status()
							self.authorized = False
						
					except requests.exceptions.HTTPError as err:
						print(f"HTTP error occurred: {err}")

			if self.received_CF and self.received_humidity and self.received_temperature:
				if self.authorized:
					print('---------------------------------------------')
					print('Someone is trying to access the Relax Room...')
					time.sleep(1)
					print('  -   Temperature:               ', self.temperature)
					print('  -   Humidity:                  ', self.humidity)
					print('  -   Number of people inside:   ', self.people_inside)
					time.sleep(2)
					print('Evaluation of safe occupancy...')
					time.sleep(1)
					owner_publish = self.owner
					safe_occupancy = self.occupancy(owner_publish)
					time.sleep(0.5)
					print('Safe occupancy: ', safe_occupancy)
					if safe_occupancy > self.people_inside + 1 and self.fixed_number_people > self.people_inside + 1 :
						self.people_inside = self.people_inside + 1
						print('User can enter the RelaxRoom!')
					else:
						print('We are sorry, but the RelaxRoom is full! Come back later...')
					print()
				else:
					owner_publish = self.owner
					self.publish_NOT_authorized(owner_publish)
				self.received_temperature = False
				self.received_humidity = False
				self.authorized = False
				self.received_CF = False
    
		def occupancy(self, owner_publish):
			new_data = {'people_inside': self.people_inside, 'temperature': self.temperature, 'humidity': self.humidity}
			# Before making a prediction, check if temperature and humidity were received
			if self.temperature is None or self.humidity is None:
				print("------------Waiting for temperature and/or humidity data---------------")
				if self.temperature is None:
					print('self.temperature is None')
				elif self.humidity is None:
					print('self.humidity is None')
				elif self.people_inside is None:
					print('self.humidity is None')
			else:
				new_data['temperature'] = self.temperature
				new_data['humidity'] = self.humidity
				new_data['people_inside'] = self.people_inside

				# Convert new_data to a list for prediction
				new_data_list = [new_data['people_inside'], new_data['temperature'], new_data['humidity']]

				# Make prediction
				self.predicted_occupancy = self.model.predict([new_data_list])[0]
				self.publish_safe_occupancy(owner_publish)
			return int(self.predicted_occupancy)

		def publish_NOT_authorized(self, owner_publish):
				owner_publish_topic = self.publish_topic.replace('name_owner', owner_publish)
				message = {
					"bn": owner_publish_topic,
					"e": [
						{
							"type": "safe_occupancy",
							"value": None,
							"timestamp": time.time()
						},
						{
							"type": "people_inside",
							"value": None,
							"timestamp": time.time()
						}
					]
				}
				self._paho_mqtt.publish(owner_publish_topic, json.dumps(message))
				print(f"Published safe occupancy: {message}")
    
		def publish_safe_occupancy(self, owner_publish):
				owner_publish_topic = self.publish_topic.replace('name_owner', owner_publish)
				message = {
					"bn": self.publish_topic,
					"e": [
						{
							"type": "safe_occupancy",
							"value": int(self.predicted_occupancy),
							"timestamp": time.time()
						},
						{
							"type": "people_inside",
							"value": int(self.people_inside),
							"timestamp": time.time()
						}
					]
				}
				self._paho_mqtt.publish(owner_publish_topic, json.dumps(message))
				print(f"Published safe occupancy: {message}")

		def train_model(self):
			data = {
				'people_inside':        [  10,   15,   11,    5,    8,   12,   9,    25,   17,   14,   17,    9,   25,   13,   19,   20,   25,    8,   28,   20,   16,   17,   10,   17,   21,   13,   18,   20,   20,   15],
				'temperature':          [22.2, 23.5, 20.7, 25.1, 24.3, 21.8, 26.2, 20.9, 19.5, 22.6, 24.1, 24.4, 24.2, 19.8, 20.3, 24.5, 20.4, 22.7, 19.9, 26.1, 22.8, 23.1, 21.0, 24.5, 20.6, 25.3, 19.7, 22.9, 21.4, 24.7],
				'humidity':             [50.2, 55.3, 60.5, 45.8, 50.9, 58.7, 62.1, 40.3, 48.2, 55.5, 45.6, 40.2, 57.3, 58.4, 44.5, 42.6, 56.7, 43.8, 42.1, 50.4, 51.7, 46.2, 57.1, 44.8, 53.6, 41.3, 49.5, 58.2, 47.4, 52.9],
				'safe_occupancy':       [  18,   15,   12,   17,   16,   16,   11,   25,   19,    16,   23,  26,   29,   19,   24,   25,   29,   22,   32,   22,   19,   17,   13,   24,   16,   25,    18,  22,   15,   24]}

			# Suppress the feature name warning (optional)
			warnings.filterwarnings("ignore")

			# Create a Pandas DataFrame for data manipulation
			df = pd.DataFrame(data)

			# Handle missing values (if any)
			df = df.dropna()  # Drops rows with missing values

			# Separate features and target variable
			X = df[['people_inside', 'temperature', 'humidity']]
			y = df['safe_occupancy']

			# Check for consistent data lengths
			if len(X) != len(y):
				print("Error: Inconsistent data lengths. Please ensure X and y have the same number of samples.")
				exit()

			# Split data into training and testing sets
			X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

			# Create and train the Random Forest model
			self.model = RandomForestRegressor(n_estimators=100, random_state=42)
			self.model.fit(X_train, y_train)

			return self.model


if __name__ == '__main__':
	service_catalog_file = "settings_service_catalog.json"
	service_catalog_info = load_json_file(service_catalog_file)
	name_microservice = 'control_fiscal_code'
	conf_file_json = json.load(open("conf_control_fiscal_code.json"))

	resource_catalog_info = get_resource_catalog(service_catalog_info)
	print(f"Resource catalog: {resource_catalog_info} \n")

	name_owner = 'name_owner'
	random_index = str(random.randint(0, 100))

	subscribe_topic = 'relax_room_iot/#'
	publish_topic_post_processing = f'relax_room_iot/microservice/actuator/safe_occupancy/{name_owner}'
		
	# Mostra le misure disponibili e verifica se ci sono sensori per l'accesso nella stanza

	print('Inserimento nuovo microservice')
	post_string = f'{service_catalog_url}/microservice'
	response = requests.post(post_string, json.dumps(conf_file_json))
	test = ML(name_owner + '_' + random_index, subscribe_topic, publish_topic_post_processing, service_catalog_info['broker'], service_catalog_info['broker_port'], resource_catalog_info['ip_address'], resource_catalog_info['ip_port'])
	test.start()

	a = 0
	while a < 200:
		a += 1
		time.sleep(3)
	test.stop()

